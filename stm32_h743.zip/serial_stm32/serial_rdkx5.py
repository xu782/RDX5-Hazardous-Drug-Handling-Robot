#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import serial
import time

class RedDetectSerialNode(Node):
    def __init__(self):
        super().__init__('red_detect_serial_node')
        
        # 🔥 串口配置
        self.serial_port = '/dev/ttyUSB0'  # 根据实际端口修改
        self.baud_rate = 115200
        self.ser = None
        
        # 初始化串口
        self.init_serial()
        
        # 订阅红色检测话题
        self.subscription = self.create_subscription(
            String,
            '/red_detected',
            self.red_detected_callback,
            10
        )
        
        self.get_logger().info('Red Detect Serial Node started!')
        
    def init_serial(self):
        """初始化串口连接"""
        try:
            self.ser = serial.Serial(
                port=self.serial_port,
                baudrate=self.baud_rate,
                timeout=1
            )
            time.sleep(0.5)  # 等待串口稳定
            self.get_logger().info(f'Serial port {self.serial_port} opened successfully')
        except Exception as e:
            self.get_logger().error(f'Failed to open serial port: {e}')
            self.ser = None
            
    def red_detected_callback(self, msg):
        """当检测到红色时发送信号给单片机"""
        if self.ser is None:
            self.get_logger().error('Serial port not initialized!')
            return
            
        try:
            # 🔥 发送信号给单片机
            # 格式：'R' + 像素数量 + '\n'
            command = f'R{msg.data.split(":")[-1].strip()}\n'
            self.ser.write(command.encode('utf-8'))
            self.get_logger().info(f'Sent to MCU: {command.strip()}')
            
        except Exception as e:
            self.get_logger().error(f'Failed to send serial data: {e}')
            
    def destroy_node(self):
        """关闭串口"""
        if self.ser is not None and self.ser.is_open:
            self.ser.close()
            self.get_logger().info('Serial port closed')
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = RedDetectSerialNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Node interrupted')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()