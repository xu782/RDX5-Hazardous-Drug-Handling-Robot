import serial
import time

def main():
    port = '/dev/ttyUSB0'
    baud_rate = 115200
    timeout = 1
    
    try:
        ser = serial.Serial(
            port=port,
            baudrate=baud_rate,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            bytesize=serial.EIGHTBITS,
            timeout=timeout
        )
        
        print(f"串口已打开: {port} @ {baud_rate} baud")
        print("等待接收STM32数据...")
        print("按 Ctrl+C 退出")
        
        while True:
            if ser.in_waiting > 0:
                data = ser.readline()
                
                try:
                    text = data.decode('utf-8').strip()
                    print(f"收到: {text}")
                except:
                    hex_str = ' '.join(f'{b:02X}' for b in data)
                    print(f"十六进制: {hex_str}")
            
            time.sleep(0.1)
            
    except serial.SerialException as e:
        print(f"串口错误: {e}")
    except KeyboardInterrupt:
        print("\n程序退出")
    finally:
        if 'ser' in locals() and ser.is_open:
            ser.close()
            print("串口已关闭")

if __name__ == "__main__":
    main()
