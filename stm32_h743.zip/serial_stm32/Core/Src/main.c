/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : 机械臂坐标控制主程序
  *                  只需输入目标坐标，机械臂自动完成抓取任务
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include "gpio.h"
#include "tim.h"
#include "usart.h"
#include "comm_protocol.h"
#include "servo_ds3120.h"
#include "gas_sensor.h"
#include "buzzer.h"
#include "oled.h"

void SystemClock_Config(void);

int main(void) 
{
  // ========== 系统初始化 ==========
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();

  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART3_UART_Init();  // 初始化串口通信（与RDK X5通信）
  GasSensor_Init();        // 初始化气体传感器 (USART2, 9600bps)
  Buzzer_Init();           // 初始化蜂鸣器 (PA3, 低电平触发)
  OLED_Init();             // 初始化 OLED (PB8=SCL, PB9=SDA)

  // ========== 舵机初始化 ==========
  Servo_Init_All();
  HAL_Delay(2000);
  Servo_Reset();

  // ========== 上电警报 ==========
  Buzzer_Alarm();

  OLED_Clear();  // 初始清屏一次
  OLED_ShowString(2, 1, "System Ready");

  // ========== 通信初始化 ==========
  Comm_Init();

  uint32_t arm_busy_tick = 0;
  uint8_t  bad_air = 0;
  // ========== 主循环 ==========
  while (1) {
    Servo_Smooth_Control();

    /* 气体传感器数据处理 — 仅更新 OLED 显示，不控制蜂鸣器 */
    if (g_gas_data_ready) {
      g_gas_data_ready = 0;
      bad_air = (g_gas_data.TVOC > 500 || g_gas_data.HCHO > 100 || g_gas_data.eCO2 > 1500);

      if (bad_air) OLED_ShowString(1, 1, "AIR BAD! STOP");
      else         OLED_ShowString(1, 1, "Air Normal    ");

      OLED_ShowString(3, 1, "TVOC:");
      OLED_ShowNum(3, 7, g_gas_data.TVOC, 5);
      OLED_ShowString(4, 1, "HCHO:");
      OLED_ShowNum(4, 7, g_gas_data.HCHO, 5);
      OLED_ShowString(5, 1, "CO2 :");
      OLED_ShowNum(5, 7, g_gas_data.eCO2, 5);

      char gas_buf[64];
      GasSensor_PrintData(gas_buf, sizeof(gas_buf));
      Comm_SendResponse(gas_buf);
      Comm_SendResponse("\n");
    }

    /* 事件驱动：RDK X5 发 "A\n" 触发机械臂 → 此时检查空气质量 */
    if (arm_trigger_flag) {
      arm_trigger_flag = 0;

      if (bad_air) {
        /* 空气差 → 蜂鸣长鸣，拒绝抓取 */
        BUZZER_ON();
        Comm_SendResponse("ARM_REJECT_AIR_BAD\n");
      } else {
        /* 空气好 → 正常抓取 */
        arm_busy_flag = 1;
        arm_busy_tick = HAL_GetTick();
        Comm_SendResponse("ARM_BUSY\n");
        Servo_GrabSequence();
        arm_busy_flag = 0;
        Comm_SendResponse("ARM_DONE\n");
      }
    }

    /* 超时保护 */
    if (arm_busy_flag && (HAL_GetTick() - arm_busy_tick > 60000)) {
      arm_busy_flag = 0;
      Comm_SendResponse("ARM_TIMEOUT\n");
    }
  }
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);
  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0);
}

void Error_Handler(void)
{
  while(1);
}
