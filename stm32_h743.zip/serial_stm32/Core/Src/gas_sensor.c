/*
 ******************************************************************************
 * @file    gas_sensor.c
 * @brief   CJ三合一气体传感器驱动 (VOC + 甲醛 + CO2)
 *          传感器型号: TVOC-CO2 数字信号三合一空气质量监测模块
 *
 * @硬件接线 (CJ三合一传感器 → STM32H743)
 *          传感器端口1 (-)    →  GND
 *          传感器端口2 (+)    →  5V
 *          传感器端口3 A(RX)  →  PD5 (USART2_TX)  [可选, 传感器主动上报]
 *          传感器端口4 B(TX)  →  PD6 (USART2_RX)
 *
 * @注意    - 传感器输出 5V 电平，PD5/PD6 是 FT 引脚可耐受 5V
 *           - 初次上电需预热 60 秒数据才稳定
 *           - 传感器每 500ms 主动发送一帧 9 字节数据
 *           - 波特率 9600, 8N1
 *
 * @协议    帧格式: 2C E4 TVOC_H TVOC_L HCHO_H HCHO_L CO2_H CO2_L Checksum
 *          校验 = 前8字节累加和(加法,非异或)
 *          TVOC(mg/m³) = (TVOC_H*256+TVOC_L)*0.001
 *          HCHO(mg/m³) = (HCHO_H*256+HCHO_L)*0.001
 *          CO2(PPM)    = CO2_H*256+CO2_L
 ******************************************************************************
 */

#include "gas_sensor.h"
#include "usart.h"
#include <string.h>
#include <stdio.h>

/* 全局变量 */
volatile GasSensorData g_gas_data = {0, 0, 0, 0, 0};
volatile uint8_t g_gas_data_ready = 0;

/* 接收缓冲区 */
static uint8_t rx_buf[9];
static uint8_t rx_index = 0;

/* USART2 句柄 */
static UART_HandleTypeDef huart2;

/**
  * @brief  初始化气体传感器串口 (USART2: PD5=TX, PD6=RX, 9600bps)
  * @note   传感器输出5V电平，PD5/PD6是FT引脚可耐受5V
  *         如通信不稳定，在RX线上串1kΩ电阻限流
  * @retval None
  */
void GasSensor_Init(void)
{
    /* 使能时钟 */
    __HAL_RCC_USART2_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();

    /* 配置 GPIO: PD5(TX) PD6(RX) */
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = GPIO_PIN_5 | GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* 配置 USART2 */
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 9600;        // 说明书: 9600bps
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart2);

    /* 使能接收中断 */
    HAL_NVIC_SetPriority(USART2_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
    __HAL_UART_ENABLE_IT(&huart2, UART_IT_RXNE);
}

/**
  * @brief  处理接收到的字节（在中断中调用）
  * @param  byte: 接收到的字节
  * @note   帧格式: 2C E4 TVOC_H TVOC_L HCHO_H HCHO_L CO2_H CO2_L Checksum
  *         Checksum = sum(B1..B8) 取低8位
  * @retval None
  */
void GasSensor_ProcessByte(uint8_t byte)
{
    /* 等待帧头 0x2C */
    if (rx_index == 0 && byte == 0x2C) {
        rx_buf[rx_index++] = byte;
    }
    else if (rx_index == 1) {
        /* B2 必须是 0xE4（模块固定地址），否则丢弃 */
        if (byte == 0xE4) {
            rx_buf[rx_index++] = byte;
        } else {
            rx_index = 0;  // 非法帧，重头开始
        }
    }
    else if (rx_index > 1) {
        rx_buf[rx_index++] = byte;

        /* 收满 9 字节 */
        if (rx_index >= 9) {
            rx_index = 0;

            /* 校验：前8字节累加和（加法，非异或）*/
            uint8_t sum = 0;
            for (int i = 0; i < 8; i++) {
                sum += rx_buf[i];
            }

            if (sum == rx_buf[8]) {
                /* 解析数据 */
                uint16_t tvoc_raw = (rx_buf[2] << 8) | rx_buf[3];
                uint16_t hcho_raw = (rx_buf[4] << 8) | rx_buf[5];
                uint16_t co2_raw  = (rx_buf[6] << 8) | rx_buf[7];

                // TVOC: raw*0.001 mg/m³ = raw ug/m³
                g_gas_data.TVOC = tvoc_raw;    // ug/m³
                // HCHO: raw*0.001 mg/m³ = raw ug/m³
                g_gas_data.HCHO = hcho_raw;    // ug/m³
                // CO2: PPM 直接
                g_gas_data.eCO2 = co2_raw;     // PPM
                g_gas_data.checksum = rx_buf[8];
                g_gas_data.valid = 1;
                g_gas_data_ready = 1;
            }
        }
    }
}

/**
  * @brief  格式化传感器数据到字符串
  * @param  buf: 输出缓冲区
  * @param  buf_size: 缓冲区大小
  * @retval None
  */
void GasSensor_PrintData(char *buf, uint16_t buf_size)
{
    if (g_gas_data.valid) {
        float tvoc_mg = g_gas_data.TVOC * 0.001f;   // ug/m³ → mg/m³
        float hcho_mg = g_gas_data.HCHO * 0.001f;
        snprintf(buf, buf_size,
                 "TVOC:%.3fmg/m3 HCHO:%.3fmg/m3 CO2:%dPPM",
                 tvoc_mg, hcho_mg, g_gas_data.eCO2);
    } else {
        snprintf(buf, buf_size, "GAS:NODATA");
    }
}

/* USART2 中断处理 */
void USART2_IRQHandler(void)
{
    if (__HAL_UART_GET_FLAG(&huart2, UART_FLAG_RXNE)) {
        uint8_t ch = (uint8_t)(huart2.Instance->RDR);
        GasSensor_ProcessByte(ch);
        __HAL_UART_CLEAR_FLAG(&huart2, UART_FLAG_RXNE);
    }
}
