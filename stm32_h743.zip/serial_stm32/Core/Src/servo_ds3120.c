/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : servo_ds3120.c
  * @brief          : DS3120舵机驱动实现
  * @author         : AI Assistant
  * @date           : 2026-05-30
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "servo_ds3120.h"
#include "tim.h"
#include "math.h"
#include "stdio.h"

/* External variables --------------------------------------------------------*/
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;

/* Private defines -----------------------------------------------------------*/
#define SERVO_MIN_ANGLE    0      // 最小角度
#define SERVO_MAX_ANGLE  180      // 最大角度
#define SERVO_SPEED       1       // 每次转动的角度步长
#define SERVO_UPDATE_MS  20      // 更新间隔(毫秒)

/* Private variables --------------------------------------------------------*/
// 舵机数量定义
#define SERVO_COUNT 6

// 上一次写入的角度（用于避免重复写PWM导致抖动）
static uint16_t last_written_angle[SERVO_COUNT] = {0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF};

// 舵机初始角度配置（编号0-5）- 修改这些值来设置初始角度
uint16_t servo_init_angle[SERVO_COUNT] = {
    0,      // [0] 舵机0初始角度 (PA8/TIM1_CH1)
    90,     // [1] 舵机1初始角度 (PA9/TIM1_CH2)
    180,      // [2] 舵机2初始角度 (PA10/TIM1_CH3)
    30,     // [3] 舵机3初始角度 (PA11/TIM1_CH4)
    0,    // [4] 舵机4初始角度 (PA0/TIM2_CH1)
    60      // [5] 舵机5初始角度 (PB4/TIM3_CH1)
};

// 6个舵机句柄（编号0-5）
Servo_HandleTypeDef servo[SERVO_COUNT] = {
    {.htim = &htim1, .channel = TIM_CHANNEL_1},  // 舵机0
    {.htim = &htim1, .channel = TIM_CHANNEL_2},  // 舵机1
    {.htim = &htim1, .channel = TIM_CHANNEL_3},  // 舵机2
    {.htim = &htim1, .channel = TIM_CHANNEL_4},  // 舵机3
    {.htim = &htim2, .channel = TIM_CHANNEL_1},  // 舵机4
    {.htim = &htim3, .channel = TIM_CHANNEL_1}   // 舵机5
};

// 6个舵机的目标角度（编号0-5）
uint16_t target_angle[SERVO_COUNT] = {90, 90, 90, 90, 90, 90};

// 舵机当前位置（编号0-5）
// 初始化为servo_init_angle中的值，确保不动时保持初始角度
uint16_t current_angle[SERVO_COUNT] = {0, 90, 180, 30, 0, 60};

/**
  * @brief  初始化所有舵机（直接转到初始角度）
  * @retval None
  */
void Servo_Init_All(void)
{
    for(uint8_t i = 0; i < SERVO_COUNT; i++) {
        Servo_Init(&servo[i]);
        // 直接设置当前角度和目标角度为初始角度（避免先转到90度）
        current_angle[i] = servo_init_angle[i];
        target_angle[i] = servo_init_angle[i];
        // 立即让舵机转到初始角度
        Servo_SetAngle(&servo[i], servo_init_angle[i]);
    }
}

/**
  * @brief  舵机平滑转动控制（需要在主循环中调用）
  * @retval None
  */
void Servo_Smooth_Control(void)
{
    static uint32_t last_servo_time = 0;

    if(HAL_GetTick() - last_servo_time >= SERVO_UPDATE_MS) {
        last_servo_time = HAL_GetTick();

        for(uint8_t i = 0; i < SERVO_COUNT; i++) {
            // 平滑转动到目标角度
            if(current_angle[i] < target_angle[i]) {
                current_angle[i] += SERVO_SPEED;
                if(current_angle[i] > target_angle[i]) {
                    current_angle[i] = target_angle[i];
                }
            } else if(current_angle[i] > target_angle[i]) {
                current_angle[i] -= SERVO_SPEED;
                if(current_angle[i] < target_angle[i]) {
                    current_angle[i] = target_angle[i];
                }
            }

            // 只在角度真正变化时才写PWM（避免每20ms无效重写导致抖动）
            if(current_angle[i] != last_written_angle[i]) {
                Servo_SetAngle(&servo[i], current_angle[i]);
                last_written_angle[i] = current_angle[i];
            }
        }
    }
}

/**
  * @brief  设置指定舵机的目标角度
  * @param  servo_id: 舵机编号（0-5）
  * @param  angle: 目标角度（0-180度）
  * @retval None
  */
void SetServoAngle(uint8_t servo_id, uint16_t angle)
{
    if(servo_id >= SERVO_COUNT) {
        return;  // 无效的舵机编号（有效范围：0-5）
    }
    
    // 角度范围限制
    if(angle < SERVO_MIN_ANGLE) {
        target_angle[servo_id] = SERVO_MIN_ANGLE;
    } else if(angle > SERVO_MAX_ANGLE) {
        target_angle[servo_id] = SERVO_MAX_ANGLE;
    } else {
        target_angle[servo_id] = angle;
    }
}

/**
  * @brief  设置所有舵机的角度
  * @param  angle0-5: 各舵机的目标角度（0-180度）
  * @retval None
  */
void SetAllServoAngles(uint16_t angle0, uint16_t angle1, uint16_t angle2, 
                       uint16_t angle3, uint16_t angle4, uint16_t angle5)
{
    SetServoAngle(0, angle0);
    SetServoAngle(1, angle1);
    SetServoAngle(2, angle2);
    SetServoAngle(3, angle3);
    SetServoAngle(4, angle4);
    SetServoAngle(5, angle5);
}

/**
  * @brief  获取指定舵机的当前角度
  * @param  servo_id: 舵机编号（0-5）
  * @retval 舵机当前角度
  */
uint16_t GetServoAngle(uint8_t servo_id)
{
    if(servo_id >= SERVO_COUNT) {
        return 0;  // 无效的舵机编号
    }
    return current_angle[servo_id];
}

/* ========================================================================== */
/* 以下是原有舵机底层驱动代码 */
/* ========================================================================== */

/* 前向声明 */
HAL_StatusTypeDef Servo_SetPulseWidth(Servo_HandleTypeDef *hservo, uint16_t pulse_width);

/**
  * @brief  初始化舵机
  * @param  hservo: 舵机句柄
  * @retval HAL状态
  */
HAL_StatusTypeDef Servo_Init(Servo_HandleTypeDef *hservo) {
    if (hservo == NULL || hservo->htim == NULL) {
        return HAL_ERROR;
    }
    
    // 启动PWM输出
    if (HAL_TIM_PWM_Start(hservo->htim, hservo->channel) != HAL_OK) {
        return HAL_ERROR;
    }
    
    // 初始角度设为90度（中间位置）
    hservo->angle = 90;
    return Servo_SetAngle(hservo, 90);
}

/**
  * @brief  设置舵机角度
  * @param  hservo: 舵机句柄
  * @param  angle: 目标角度 (0-180度)
  * @retval HAL状态
  */
HAL_StatusTypeDef Servo_SetAngle(Servo_HandleTypeDef *hservo, uint16_t angle) {
    if (hservo == NULL || hservo->htim == NULL) {
        return HAL_ERROR;
    }
    
    // 限制角度范围
    if (angle > SERVO_MAX_ANGLE) {
        angle = SERVO_MAX_ANGLE;
    } else if (angle < SERVO_MIN_ANGLE) {
        angle = SERVO_MIN_ANGLE;
    }
    
    hservo->angle = angle;
    
    // 计算脉冲宽度
    // 脉冲宽度 = SERVO_MIN_PULSE + (angle / 180) * (SERVO_MAX_PULSE - SERVO_MIN_PULSE)
    uint16_t pulse_width = SERVO_MIN_PULSE + 
                          ((uint32_t)angle * (SERVO_MAX_PULSE - SERVO_MIN_PULSE)) / 180;
    
    return Servo_SetPulseWidth(hservo, pulse_width);
}

/**
  * @brief  设置舵机脉冲宽度
  * @param  hservo: 舵机句柄
  * @param  pulse_width: 脉冲宽度 (us)
  * @retval HAL状态
  */
HAL_StatusTypeDef Servo_SetPulseWidth(Servo_HandleTypeDef *hservo, uint16_t pulse_width) {
    if (hservo == NULL || hservo->htim == NULL) {
        return HAL_ERROR;
    }
    
    // 限制脉冲宽度范围
    if (pulse_width > SERVO_MAX_PULSE) {
        pulse_width = SERVO_MAX_PULSE;
    } else if (pulse_width < SERVO_MIN_PULSE) {
        pulse_width = SERVO_MIN_PULSE;
    }
    
    // 获取定时器自动重装载值
    uint32_t arr = __HAL_TIM_GET_AUTORELOAD(hservo->htim);
    
    // 计算比较值
    // 比较值 = (pulse_width * (arr + 1)) / (1000000 / SERVO_PWM_FREQ)
    uint32_t compare_value = ((uint32_t)pulse_width * (arr + 1)) / (1000000 / SERVO_PWM_FREQ);
    
    // 设置比较值
    __HAL_TIM_SET_COMPARE(hservo->htim, hservo->channel, compare_value);
    
    return HAL_OK;
}

/**
  * @brief  获取当前舵机角度
  * @param  hservo: 舵机句柄
  * @retval 当前角度
  */
uint16_t Servo_GetAngle(Servo_HandleTypeDef *hservo) {
    if (hservo == NULL) {
        return 0;
    }
    return hservo->angle;
}

/* ==================== 逆运动学求解函数 ==================== */

/**
  * @brief  6自由度机械臂逆运动学求解核心算法
  * @details 本函数采用"几何解析+遍历搜索"的混合方法求解逆运动学
  *          机械臂结构：J1(底座旋转) -> J2(肩部) -> J3(大臂) -> J4(小臂) -> J5(腕部) -> J6(夹爪)
  *          求解思路：将6自由度问题简化为3自由度平面问题求解
  * @param  target_x: 目标X坐标（水平方向偏移，cm）
  * @param  target_y: 目标Y坐标（前后距离，cm），必须在[ARM_MIN_Y, ARM_MAX_Y]范围内
  * @param  target_z: 目标Z坐标（高度，cm）
  * @retval None（结果存入全局变量 target_angle[0-5]）
  */
void Servo_IK_Calculate(float target_x, float target_y, float target_z)
{
    /* ============= 阶段1：工作空间边界检查 ============= */
    // 机械臂有物理工作空间限制，超出范围会触发安全保护
    // Y轴限制：[ARM_MIN_Y, ARM_MAX_Y] = [5cm, 15cm]
    if(target_y < ARM_MIN_Y || target_y > ARM_MAX_Y)
    {
        // 超出工作空间，设置为安全位置（预计算的0度姿态）
        target_angle[5] = 60;   // J1: 底座旋转，中间位置
        target_angle[4] = 5.41506;   // J2: 0度对应的舵机角度
        target_angle[3] = 18.541896; // J3: 0度对应的舵机角度
        target_angle[2] = 84.050999;  // J4: 0度对应的舵机角度（-90~90 → 0~180映射）
        target_angle[1] = 90;   // J5: 腕部中间位置
        target_angle[0] = 0;    // J6: 夹爪打开
        return;
    }
        
    /* ============= 阶段2：变量初始化 ============= */
    // 机械臂物理参数（从配置宏加载）
    float len_1 = ARM_LEN_1;   // 底座高度（2.5cm）
    float len_2 = ARM_LEN_2;   // 大臂长度（13.0cm）
    float len_3 = ARM_LEN_3;   // 小臂长度（9.0cm）
    float len_4 = ARM_LEN_4;   // 末端执行器长度（11.0cm）
    float bottom_r = ARM_BOTTOM_R; // 底座半径（8.0cm）
    
    // 关节角度变量（单位：度）
    float j1, j2, j3, j4;      // J1~J4角度，J5/J6固定
    
    // 中间计算变量
    float L, H;                // 末端相对坐标（相对于J2关节）
    float j_sum;               // J2+J3+J4总角度和（决定末端姿态）
    float len, high;           // 目标点的水平距离和高度
    float cos_j3, sin_j3;      // J3角度的三角函数值
    float cos_j2, sin_j2;      // J2角度的三角函数值
    float k1, k2;              // 辅助计算变量
    int i;                     // 循环计数器
    int n = 0, m = 0;          // n:可行解总数, m:当前可行解计数

    /* ============= 阶段3：计算J1（底座旋转角度） ============= */
    // J1是绕Z轴的水平旋转，将3D问题投影到J1旋转后的平面
    // 坐标系：X=0,Y>0为正前方
    if (target_x == 0)
        j1 = 60;  // X=0时，正前方，无需旋转
    else
        // atan(target_x/(target_y+bottom_r)) 计算水平偏角
        // 57.3 = 180/π，用于弧度转角度
        // j1范围：0°(左) ~ 90°(前) ~ 180°(右)
        j1 = 60 - atan(target_x / (target_y + bottom_r)) * 57.3;

    /* ============= 阶段4：第一次遍历 - 统计可行解数量 ============= */
    // 核心思想：遍历所有可能的末端姿态角（0~180度），找出满足约束的可行解
    // 为什么要遍历？因为6自由度机械臂存在多解性，需要找到最优解
    for (i = 0; i <= 180; i++)
    {
        // j_sum: J2+J3+J4的总角度和（0~π弧度）
        // 这个角度决定了末端执行器的姿态（前倾/后仰）
        j_sum = 3.1415927f * i / 180.0f;  // 度转弧度
        
        /* 步骤4.1：计算目标点到旋转中心的水平距离 */
        // 使用勾股定理计算：距离 = √[(Y+底座半径)² + X²]
        // target_y+bottom_r: 目标点到底座中心的实际Y距离
        len = sqrt((target_y + bottom_r) * (target_y + bottom_r) + target_x * target_x);
        high = target_z;  // 目标高度直接使用

        /* 步骤4.2：计算末端执行器相对坐标（L, H） */
        // 将目标点坐标转换到J2关节坐标系
        // 减去末端执行器的影响（因为末端执行器有固定长度）
        // L: 水平方向相对距离
        // H: 垂直方向相对距离（相对于J2关节高度）
        L = len - len_4 * sin(j_sum);
        H = high - len_4 * cos(j_sum) - len_1;

        /* 步骤4.3：余弦定理求J3角度 */
        // 余弦定理：c² = a² + b² - 2ab*cos(C)
        // 这里用余弦定理求三角形（J2-J3-J4末端）中J3的角度
        // L和H是J2到目标点的相对坐标，len_2和len_3是大臂小臂长度
        cos_j3 = ((L * L) + (H * H) - len_2 * len_2 - len_3 * len_3) / (2 * len_2 * len_3);
        
        // 数值稳定性保护：cos值必须在[-1,1]范围内
        // 由于浮点精度问题可能超出范围，需要钳位
        if(cos_j3 > 1.0f) cos_j3 = 1.0f;
        else if(cos_j3 < -1.0f) cos_j3 = -1.0f;
        
        // 由余弦值求正弦值
        sin_j3 = sqrt(1 - cos_j3 * cos_j3);
        // atan2(y, x)返回弧度，乘以57.3转为角度
        j3 = atan2(sin_j3, cos_j3) * 57.3f;

        /* 步骤4.4：计算中间变量k1, k2 */
        // k1, k2是将大臂+小臂视为一个整体后的等效长度分量
        // k1: 水平分量（len_2 + len_3*cos(j3)）
        // k2: 垂直分量（len_3*sin(j3)）
        k2 = len_3 * sin(j3 / 57.3f);
        k1 = len_2 + len_3 * cos(j3 / 57.3f);

        /* 步骤4.5：求J2角度 */
        // 使用几何关系：cos(j2) = (k2*L + k1*H) / (k1² + k2²)
        // 这是将目标点投影到等效臂的方向上
        cos_j2 = (k2 * L + k1 * H) / (k1 * k1 + k2 * k2);
        
        // 同样进行数值范围保护
        if(cos_j2 > 1.0f) cos_j2 = 1.0f;
        else if(cos_j2 < -1.0f) cos_j2 = -1.0f;
        
        sin_j2 = sqrt(1 - cos_j2 * cos_j2);
        j2 = atan2(sin_j2, cos_j2) * 57.3f;
        
        /* 步骤4.6：求J4角度 */
        // J4 = 总角度和 - J2 - J3
        // 因为j_sum = j2 + j3 + j4（弧度）
        j4 = j_sum * 57.3f - j2 - j3;
        
        /* 步骤4.7：检查角度范围约束 */
        // 各关节角度必须在物理范围内：
        // J2: 0~90°（肩部只能向上抬）
        // J3: 0~90°（大臂只能向下摆）
        // J4: -90~90°（小臂可上下摆动）
        if (j2 > 0 && j3 > 0 && j4 > -90 && j2 < 90 && j3 < 90 && j4 < 90)
        {
            n++;  // 满足所有约束，可行解计数加1
        }
    }
    
    /* ============= 阶段5：第二次遍历 - 选择最优中间解 ============= */
    // 为什么选中间解？
    // 1. 避免边界解：边界解可能处于机械臂奇异位置，运动不稳定
    // 2. 保证运动平滑：中间解通常是最"自然"的姿态
    for (i = 0; i <= 180; i++)
    {
        // 重复计算（与第一次遍历相同）
        j_sum = 3.1415927f * i / 180.0f;
        len = sqrt((target_y + bottom_r) * (target_y + bottom_r) + target_x * target_x);
        high = target_z;

        L = len - len_4 * sin(j_sum);
        H = high - len_4 * cos(j_sum) - len_1;

        cos_j3 = ((L * L) + (H * H) - len_2 * len_2 - len_3 * len_3) / (2 * len_2 * len_3);
        if(cos_j3 > 1.0f) cos_j3 = 1.0f;
        else if(cos_j3 < -1.0f) cos_j3 = -1.0f;
        
        sin_j3 = sqrt(1 - cos_j3 * cos_j3);
        j3 = atan2(sin_j3, cos_j3) * 57.3f;

        k2 = len_3 * sin(j3 / 57.3f);
        k1 = len_2 + len_3 * cos(j3 / 57.3f);

        cos_j2 = (k2 * L + k1 * H) / (k1 * k1 + k2 * k2);
        if(cos_j2 > 1.0f) cos_j2 = 1.0f;
        else if(cos_j2 < -1.0f) cos_j2 = -1.0f;
        
        sin_j2 = sqrt(1 - cos_j2 * cos_j2);
        j2 = atan2(sin_j2, cos_j2) * 57.3f;
        j4 = j_sum * 57.3f - j2 - j3;

        // 检查角度约束
        if (j2 > 0 && j3 > 0 && j4 > -90 && j2 < 90 && j3 < 90 && j4 < 90)
        {
            m++;  // 当前可行解计数
            
            // 选择中间解（避免边界奇异点）
            // n/2 和 (n+1)/2 分别处理偶数和奇数个可行解的情况
            // 例如：n=4时选第2个，n=5时选第2或第3个
            if (m == n / 2 || m == (n + 1) / 2) 
            {
                break;  // 找到中间解，退出循环
            }			
        }
    }
    
    /* ============= 阶段6：输出角度映射 ============= */
    // 将计算出的关节角度映射到舵机角度（0~180度）
    // 注意：舵机编号与关节编号的对应关系：
    // 关节J1→舵机5, J2→舵机4, J3→舵机3, J4→舵机2, J5→舵机1, J6→舵机0
    
    // J1（底座旋转）：计算值0~180度，直接映射
    target_angle[5] = (uint16_t)(j1 + 0.5f);           // 舵机5
    
    // J2（肩部）：计算值0~90度，直接映射
    target_angle[4] = (uint16_t)(j2 + 0.5f);           // 舵机4
    
    // J3（大臂）：计算值0~90度，直接映射
    target_angle[3] = (uint16_t)(j3 + 0.5f);           // 舵机3
    
    // J4（小臂）：计算值-90~90度，需要偏移90度转为0~180度
    target_angle[2] = (uint16_t)(j4 + 90 + 0.5f);      // 舵机2
    
    // J5（腕部）：固定在中间位置（90度），不参与逆解
    target_angle[1] = 90;                              // 舵机1
    
    // J6（夹爪）：固定打开状态（20度），抓取时单独控制
    target_angle[0] = 20;                              // 舵机0
    
    /* ============= 阶段7：最终角度范围限制 ============= */
    // 确保所有角度在舵机物理范围内（SERVO_MIN_ANGLE~SERVO_MAX_ANGLE）
    // 防止计算误差导致角度超出范围
    for(i = 0; i < SERVO_COUNT; i++) {
        if(target_angle[i] < SERVO_MIN_ANGLE) target_angle[i] = SERVO_MIN_ANGLE;
        if(target_angle[i] > SERVO_MAX_ANGLE) target_angle[i] = SERVO_MAX_ANGLE;
    }
    
    /* ============= 算法结束 ============= */
    // 结果：target_angle[0-5] 数组包含各舵机的目标角度
    // 后续由 Servo_Smooth_Control() 函数驱动舵机平滑移动到目标角度
}

/**
  * @brief  等待机械臂到达目标位置
  * @retval None
  */
void Servo_Wait_Reach(void)
{
    uint8_t reached;
    do {
        reached = 1;
        // 必须调用 Servo_Smooth_Control() 来驱动舵机移动
        Servo_Smooth_Control();
        for(uint8_t i = 0; i < SERVO_COUNT; i++) {
            if(current_angle[i] != target_angle[i]) {
                reached = 0;
                break;
            }
        }
        HAL_Delay(10);
    } while(!reached);
    
    HAL_Delay(500);  // 稳定0.5秒
}

/**
  * @brief  机械臂抓取物体
  * @retval None
  */
void Servo_Grab(void)
{
    // 等待到达抓取位置
    Servo_Wait_Reach();
    
    // 夹爪夹紧（舵机0，J6=70°）
    SetServoAngle(0, 70);
    Servo_Wait_Reach();
}

/**
  * @brief  机械臂抬起到安全高度
  * @retval None
  */
void Servo_Lift(void)
{
    // 第一阶段：J2/J3/J4 先抬起到安全高度
    SetServoAngle(4, 15);   // J2（舵机4）
    SetServoAngle(3, 15);   // J3（舵机3）
    SetServoAngle(2, 135);  // J4（舵机2）-90~90 → 0~180，35°对应125°
    Servo_Wait_Reach();     // 等 J2/J3/J4 到位后再动 J5，避免碰撞

    // 第二阶段：J5 旋转
    SetServoAngle(5, 140);
    Servo_Wait_Reach();
}

/**
  * @brief  一键移动到目标坐标并抓取（高级封装函数）
  * @details 完整的抓取流程：
  *          1. 移动到目标坐标（使用逆运动学）
  *          2. 夹爪夹紧抓取物体
  *          3. 抬起到安全高度
  *          4. 释放夹爪放下物体
  *          5. 复位到初始位置
  * @param  target_x: 目标X坐标（水平方向，cm）
  * @param  target_y: 目标Y坐标（前后距离，cm），必须在[5, 15]范围内
  * @param  target_z: 目标Z坐标（高度，cm）
  * @retval None
  * @note   这是最常用的函数，只需调用一次即可完成完整的抓取流程
  *         Y坐标超出范围会自动触发安全保护
  * @note   需要在主循环中调用 Servo_Smooth_Control() 来驱动舵机
  */
void Servo_MoveToPosition(float target_x, float target_y, float target_z)
{
    // 步骤1：移动到目标位置（使用逆运动学计算）
    Servo_IK_Calculate(target_x, target_y, target_z);
    Servo_Wait_Reach();
    HAL_Delay(300);  // 稳定300ms
    
    // 步骤2：夹爪夹紧抓取物体
    Servo_Grab();
    
    // 步骤3：抬起到安全高度
    Servo_Lift();
    
    // 步骤4：释放夹爪放下物体
    SetServoAngle(0, 20);  // 打开夹爪（J6=20°）
    Servo_Wait_Reach();
    
    // 步骤5：复位到初始位置
    Servo_Reset();
}

/**
  * @brief  仅移动到目标坐标（不抓取）
  * @param  target_x: 目标X坐标（水平方向，cm）
  * @param  target_y: 目标Y坐标（前后距离，cm），必须在[5, 15]范围内
  * @param  target_z: 目标Z坐标（高度，cm）
  * @retval None
  * @note   用于测试机械臂位置或只需要移动的场景
  */
void Servo_MoveOnly(float target_x, float target_y, float target_z)
{
    // 使用逆运动学计算并移动到目标位置
    Servo_IK_Calculate(target_x, target_y, target_z);
    Servo_Wait_Reach();
}

// 抓取姿态角度（直接调角度，不用逆解）
// [0]J6夹爪 [1]J1 [2]J4 [3]J3 [4]J2 [5]J5
static uint16_t grab_angles[SERVO_COUNT] = {70, 90, 0, 90, 90, 60};

/**
  * @brief  简单抓取序列（直接角度控制，不用逆解算）
  * @retval None
  * @note   修改 grab_angles[] 数组来调整抓取姿态
  *         流程: 抬升 → 抓取姿态 → 夹紧 → 抬升 → 释放 → 复位
  */
void Servo_GrabSequence(void)
{
    // 步骤2-1：J3、J4、J1、J5、J6 先到位（J2 暂不动）
    SetServoAngle(3, 25 );   // J3
    SetServoAngle(2, 45);   // J4
    SetServoAngle(1, 90);   // J1
    SetServoAngle(5, 60);   // J5
    SetServoAngle(0, 0);    // J6
    Servo_Wait_Reach();

    // 步骤2-2：其他舵机到位后，J2 最后动（舵机4到90°）
    SetServoAngle(4, 90);   // J2
    Servo_Wait_Reach();
    HAL_Delay(300);

    // 步骤3：夹爪夹紧
    Servo_Grab();

    // 步骤4：抬起到安全高度
    Servo_Lift();

    // 步骤5：释放夹爪
    SetServoAngle(0, 20);
    Servo_Wait_Reach();
    HAL_Delay(300);

    // 步骤6：复位
    Servo_Reset();
}

/**
  * @brief  机械臂复位到初始位置
  * @retval None
  * @note   使用servo_init_angle数组中定义的初始角度
  */
void Servo_Reset(void)
{
    // 使用servo_init_angle数组中的初始角度复位
    for(uint8_t i = 0; i < SERVO_COUNT; i++) {
        SetServoAngle(i, servo_init_angle[i]);
    }
    Servo_Wait_Reach();

    // 强制清除跟踪状态，确保下一轮 PWM 全部重写
    for(uint8_t i = 0; i < SERVO_COUNT; i++) {
        last_written_angle[i] = 0xFFFF;
    }

    HAL_Delay(1000);
}
