/*
 ******************************************************************************
 * @file    buzzer.c
 * @brief   有源蜂鸣器驱动 (低电平触发)
 *          模块型号: MH-FMD (有源电磁式, S8550 PNP驱动)
 *
 * @硬件接线 (蜂鸣器模块 → STM32H743)
 *          VCC → 3.3V 或 5V
 *          GND → GND
 *          I/O → PA3
 *
 * @注意    - 低电平触发: I/O=0V 蜂鸣器响, I/O=3.3V 蜂鸣器停
 *           - 上电默认 I/O 拉高, 避免开机误鸣
 *           - 供电不超过 5V, 否则烧毁三极管
 ******************************************************************************
 */

#include "buzzer.h"

/**
  * @brief  初始化蜂鸣器 GPIO
  * @retval None
  */
void Buzzer_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = BUZZER_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(BUZZER_PORT, &GPIO_InitStruct);

    BUZZER_OFF();  // 默认关蜂鸣器
}

/**
  * @brief  蜂鸣器鸣叫 N 次
  * @param  on_ms:  每次鸣叫持续时间 (ms)
  * @param  off_ms: 每次间隔时间 (ms)
  * @param  count:  鸣叫次数
  * @retval None
  */
void Buzzer_Beep(uint16_t on_ms, uint16_t off_ms, uint8_t count)
{
    for (uint8_t i = 0; i < count; i++) {
        BUZZER_ON();
        HAL_Delay(on_ms);
        BUZZER_OFF();
        if (i < count - 1) {
            HAL_Delay(off_ms);
        }
    }
}

/**
  * @brief  上电警报 — 三声短鸣
  * @retval None
  */
void Buzzer_Alarm(void)
{
    Buzzer_Beep(200, 100, 3);  // 滴滴滴
}
