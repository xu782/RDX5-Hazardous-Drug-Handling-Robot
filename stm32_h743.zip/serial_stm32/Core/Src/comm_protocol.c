#include "comm_protocol.h"
#include "usart.h"
#include <string.h>

ReceiveFrame rx_frame;
SendFrame tx_frame;
uint8_t rx_buffer[32];
uint8_t rx_index = 0;
volatile uint8_t rx_flag = 0;
uint8_t rx_data;

volatile uint8_t red_detected_flag = 0;
volatile uint16_t red_pixel_count = 0;

/* 机械臂控制标志 */
volatile uint8_t arm_trigger_flag = 0;  /* 收到 'A' 命令时置1 */
volatile uint8_t arm_busy_flag = 0;     /* 机械臂正在执行中 */

uint8_t Comm_CalculateBCC(uint8_t *data, uint16_t len) {
    uint8_t bcc = 0;
    for(uint16_t i = 0; i < len; i++) {
        bcc ^= data[i];
    }
    return bcc;
}

void Comm_SendData(void) {
    uint8_t buffer[RECEIVE_DATA_SIZE] = {0};

    buffer[0] = FRAME_HEADER;
    buffer[1] = tx_frame.flag;

    buffer[2] = (tx_frame.speed_x >> 8) & 0xFF;
    buffer[3] = tx_frame.speed_x & 0xFF;
    buffer[4] = (tx_frame.speed_y >> 8) & 0xFF;
    buffer[5] = tx_frame.speed_y & 0xFF;
    buffer[6] = (tx_frame.speed_z >> 8) & 0xFF;
    buffer[7] = tx_frame.speed_z & 0xFF;

    buffer[8] = (tx_frame.acc_x >> 8) & 0xFF;
    buffer[9] = tx_frame.acc_x & 0xFF;
    buffer[10] = (tx_frame.acc_y >> 8) & 0xFF;
    buffer[11] = tx_frame.acc_y & 0xFF;
    buffer[12] = (tx_frame.acc_z >> 8) & 0xFF;
    buffer[13] = tx_frame.acc_z & 0xFF;

    buffer[14] = (tx_frame.gyro_x >> 8) & 0xFF;
    buffer[15] = tx_frame.gyro_x & 0xFF;
    buffer[16] = (tx_frame.gyro_y >> 8) & 0xFF;
    buffer[17] = tx_frame.gyro_y & 0xFF;
    buffer[18] = (tx_frame.gyro_z >> 8) & 0xFF;
    buffer[19] = tx_frame.gyro_z & 0xFF;

    buffer[20] = (tx_frame.voltage >> 8) & 0xFF;
    buffer[21] = tx_frame.voltage & 0xFF;

    buffer[22] = Comm_CalculateBCC(buffer, 22);
    buffer[23] = FRAME_TAIL;

    HAL_UART_Transmit(&huart3, buffer, RECEIVE_DATA_SIZE, 100);
}

void Comm_ProcessByte(uint8_t data) {
    /* ---- 'A' 命令：机械臂触发 ---- */
    if(data == 'A' && rx_index == 0) {
        rx_buffer[rx_index++] = data;
        return;
    }

    if(rx_index == 1 && rx_buffer[0] == 'A') {
        if(data == '\n') {
            /* 收到完整的 "A\n" → 触发机械臂任务 */
            if(!arm_busy_flag) {
                arm_trigger_flag = 1;
                rx_flag = 3;  /* rx_flag=3 表示收到机械臂触发命令 */
            }
            rx_index = 0;
            return;
        }
        /* 不是 '\n'，非法命令，丢弃 */
        rx_index = 0;
        return;
    }

    /* ---- 'R' 命令：红色检测数据 ---- */
    if(data == 'R' && rx_index == 0) {
        rx_buffer[rx_index++] = data;
    }
    else if(rx_index > 0 && rx_index < 32 && data >= '0' && data <= '9') {
        rx_buffer[rx_index++] = data;
    }
    else if(data == '\n' && rx_index > 1) {
        rx_buffer[rx_index] = '\0';

        uint16_t count = 0;
        for(uint8_t i = 1; i < rx_index; i++) {
            count = count * 10 + (rx_buffer[i] - '0');
        }

        red_pixel_count = count;

        if(count >= 12000) {
            red_detected_flag = 1;
        } else {
            red_detected_flag = 0;
        }

        rx_flag = 1;
        rx_index = 0;
    }
    else {
        rx_index = 0;
    }
}

void Comm_Init(void) {
    HAL_UART_Receive_IT(&huart3, &rx_data, 1);
    tx_frame.flag = 0x00;
}

/**
  * @brief  发送字符串响应到 RDK X5
  * @param  msg: 要发送的字符串（必须以 null 结尾）
  * @retval None
  */
void Comm_SendResponse(const char *msg) {
    if(msg == NULL) return;
    uint16_t len = (uint16_t)strlen(msg);
    if(len > 0) {
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, len, 100);
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if(huart->Instance == USART3) {
        Comm_ProcessByte(rx_data);
        HAL_UART_Receive_IT(&huart3, &rx_data, 1);
    }
}