/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : tim.h
  * @brief          : TIM1/TIM2 PWM配置头文件（5路舵机控制）
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef TIM_H
#define TIM_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"
#include "stm32h7xx_hal_tim.h"

extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;

void MX_TIM1_Init(void);
void MX_TIM2_Init(void);
void MX_TIM3_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* TIM_H */