#ifndef COMM_PROTOCOL_H
#define COMM_PROTOCOL_H

#include "stm32h7xx_hal.h"

#define FRAME_HEADER      0x7B
#define FRAME_TAIL        0x7D
#define SEND_DATA_SIZE    11
#define RECEIVE_DATA_SIZE 24

typedef struct {
    uint8_t auto_recharge;
    uint8_t security_level;
    int16_t speed_x;
    int16_t speed_y;
    int16_t speed_z;
} ReceiveFrame;

typedef struct {
    uint8_t flag;
    int16_t speed_x;
    int16_t speed_y;
    int16_t speed_z;
    int16_t acc_x;
    int16_t acc_y;
    int16_t acc_z;
    int16_t gyro_x;
    int16_t gyro_y;
    int16_t gyro_z;
    uint16_t voltage;
} SendFrame;

extern UART_HandleTypeDef huart3;
extern ReceiveFrame rx_frame;
extern SendFrame tx_frame;
extern uint8_t rx_buffer[32];
extern uint8_t rx_index;
extern volatile uint8_t rx_flag;
extern volatile uint8_t red_detected_flag;
extern volatile uint16_t red_pixel_count;

/* 机械臂控制标志 */
extern volatile uint8_t arm_trigger_flag;   /* RDK X5 发来 'A' 命令时置1，main循环消费 */
extern volatile uint8_t arm_busy_flag;      /* 机械臂正在执行中，阻止重复触发 */

void Comm_Init(void);
void Comm_SendData(void);
void Comm_ProcessByte(uint8_t data);
uint8_t Comm_CalculateBCC(uint8_t *data, uint16_t len);
void Comm_SendResponse(const char *msg);     /* 发送字符串响应到 RDK X5 */

#endif