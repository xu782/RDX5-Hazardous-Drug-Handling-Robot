#ifndef __GAS_SENSOR_H__
#define __GAS_SENSOR_H__

#include "main.h"

/* 气体传感器数据结构 */
typedef struct {
    uint16_t TVOC;     // TVOC浓度 (ug/m3)
    uint16_t HCHO;     // 甲醛浓度 (ug/m3)
    uint16_t eCO2;     // 等效二氧化碳浓度 (PPM)
    uint8_t  checksum; // 校验和
    uint8_t  valid;    // 数据有效标志（1=新数据就绪）
} GasSensorData;

/* 全局传感器数据 */
extern volatile GasSensorData g_gas_data;
extern volatile uint8_t g_gas_data_ready;

/* 函数声明 */
void GasSensor_Init(void);
void GasSensor_ProcessByte(uint8_t byte);
void GasSensor_PrintData(char *buf, uint16_t buf_size);

#endif /* __GAS_SENSOR_H__ */
