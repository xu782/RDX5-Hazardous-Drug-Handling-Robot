/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : servo_ds3120.h
  * @brief          : DS3120舵机驱动头文件
  * @author         : AI Assistant
  * @date           : 2026-05-30
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef __SERVO_DS3120_H
#define __SERVO_DS3120_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stdint.h"

/* Public defines ------------------------------------------------------------*/
#define SERVO_PWM_FREQ     50      // PWM频率(Hz)
#define SERVO_MIN_PULSE    500     // 最小脉冲宽度(us)
#define SERVO_MAX_PULSE    2500    // 最大脉冲宽度(us)

/* 机械臂物理参数 */
#define ARM_BOTTOM_R       14.0f    // 底座半径(cm)
#define ARM_LEN_1          2.5f    // 底座高度(cm)
#define ARM_LEN_2          13.0f    // 大臂长度(cm)
#define ARM_LEN_3          9.0f    // 小臂长度(cm)
#define ARM_LEN_4          11.0f   // 末端执行器长度(cm)

/* 工作空间约束 */
#define ARM_MIN_Y          5.0f    // 最小Y坐标(cm)
#define ARM_MAX_Y          15.0f   // 最大Y坐标(cm)

/* Public types --------------------------------------------------------------*/
typedef struct {
    TIM_HandleTypeDef *htim;   // 定时器句柄
    uint32_t channel;          // 定时器通道
    uint16_t angle;           // 当前角度
} Servo_HandleTypeDef;

/* Public variables ----------------------------------------------------------*/
extern uint16_t servo_init_angle[6];
extern Servo_HandleTypeDef servo[6];
extern uint16_t target_angle[6];
extern uint16_t current_angle[6];

/* Public function prototypes ------------------------------------------------*/

/**
  * @brief  初始化所有舵机（直接转到初始角度）
  * @retval None
  */
void Servo_Init_All(void);

/**
  * @brief  舵机平滑转动控制（需要在主循环中调用）
  * @retval None
  */
void Servo_Smooth_Control(void);

/**
  * @brief  设置指定舵机的目标角度
  * @param  servo_id: 舵机编号（0-5）
  * @param  angle: 目标角度（0-180度）
  * @retval None
  */
void SetServoAngle(uint8_t servo_id, uint16_t angle);

/**
  * @brief  设置所有舵机的角度
  * @param  angle0-5: 各舵机的目标角度（0-180度）
  * @retval None
  */
void SetAllServoAngles(uint16_t angle0, uint16_t angle1, uint16_t angle2, 
                       uint16_t angle3, uint16_t angle4, uint16_t angle5);

/**
  * @brief  获取指定舵机的当前角度
  * @param  servo_id: 舵机编号（0-5）
  * @retval 舵机当前角度
  */
uint16_t GetServoAngle(uint8_t servo_id);

/**
  * @brief  初始化舵机
  * @param  hservo: 舵机句柄
  * @retval HAL状态
  */
HAL_StatusTypeDef Servo_Init(Servo_HandleTypeDef *hservo);

/**
  * @brief  设置舵机角度
  * @param  hservo: 舵机句柄
  * @param  angle: 目标角度 (0-180度)
  * @retval HAL状态
  */
HAL_StatusTypeDef Servo_SetAngle(Servo_HandleTypeDef *hservo, uint16_t angle);

/**
  * @brief  获取当前舵机角度
  * @param  hservo: 舵机句柄
  * @retval 当前角度
  */
uint16_t Servo_GetAngle(Servo_HandleTypeDef *hservo);

/* ==================== 逆运动学求解函数 ==================== */

/**
  * @brief  根据目标坐标计算各关节角度（逆运动学求解）
  * @param  target_x: 目标X坐标（水平距离，cm）
  * @param  target_y: 目标Y坐标（垂直距离，cm）
  * @param  target_z: 目标Z坐标（高度，cm）
  * @retval None（结果存入全局变量 target_angle[0-5]）
  * @note   Y坐标必须在 [5, 15] cm范围内，超出则设为安全位置
  */
void Servo_IK_Calculate(float target_x, float target_y, float target_z);

/**
  * @brief  机械臂抓取物体
  * @retval None
  * @note   使用逆运动学计算的目标角度移动到抓取位置，夹爪夹紧
  */
void Servo_Grab(void);

/**
  * @brief  机械臂抬起到安全高度
  * @retval None
  */
void Servo_Lift(void);

/**
  * @brief  等待机械臂到达目标位置
  * @retval None
  */
void Servo_Wait_Reach(void);

/**
  * @brief  机械臂复位到初始位置
  * @retval None
  */
void Servo_Reset(void);

/**
  * @brief  一键移动到目标坐标并抓取（高级封装函数）
  * @details 完整的抓取流程：
  *          1. 移动到目标坐标（使用逆运动学）
  *          2. 夹爪夹紧抓取物体
  *          3. 抬起到安全高度
  *          4. 释放夹爪放下物体
  *          5. 复位到初始位置
  * @param  target_x: 目标X坐标（水平方向，cm）
  * @param  target_y: 目标Y坐标（前后距离，cm），必须在[5, 15]范围内
  * @param  target_z: 目标Z坐标（高度，cm）
  * @retval None
  * @note   这是最常用的函数，只需调用一次即可完成完整的抓取流程
  */
void Servo_MoveToPosition(float target_x, float target_y, float target_z);

/**
  * @brief  仅移动到目标坐标（不抓取）
  * @param  target_x: 目标X坐标（水平方向，cm）
  * @param  target_y: 目标Y坐标（前后距离，cm），必须在[5, 15]范围内
  * @param  target_z: 目标Z坐标（高度，cm）
  * @retval None
  * @note   用于测试机械臂位置或只需要移动的场景
  */
void Servo_MoveOnly(float target_x, float target_y, float target_z);
void Servo_GrabSequence(void);  // 简单抓取（直接角度，不用逆解），修改grab_angles[]调姿态

#ifdef __cplusplus
}
#endif

#endif /* __SERVO_DS3120_H */
