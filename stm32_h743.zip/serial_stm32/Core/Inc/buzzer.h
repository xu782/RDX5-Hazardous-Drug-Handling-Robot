#ifndef __BUZZER_H__
#define __BUZZER_H__

#include "main.h"

/* 蜂鸣器引脚定义 */
#define BUZZER_PORT     GPIOA
#define BUZZER_PIN      GPIO_PIN_3

/* 蜂鸣器控制宏 */
#define BUZZER_ON()     HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, GPIO_PIN_RESET)  // 低电平响
#define BUZZER_OFF()    HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, GPIO_PIN_SET)    // 高电平停

/* 函数声明 */
void Buzzer_Init(void);
void Buzzer_Beep(uint16_t on_ms, uint16_t off_ms, uint8_t count);  // 蜂鸣N次
void Buzzer_Alarm(void);  // 上电警报

#endif /* __BUZZER_H__ */
