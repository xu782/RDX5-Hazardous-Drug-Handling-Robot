#include "comm_protocol.h"


ReceiveFrame rx_frame;
SendFrame tx_frame;
uint8_t rx_buffer[SEND_DATA_SIZE];
uint8_t rx_index = 0;
uint8_t rx_flag = 0;

// BCC校验计算
uint8_t Comm_CalculateBCC(uint8_t *data, uint16_t len) {
    uint8_t bcc = 0;
    for(uint16_t i = 0; i < len; i++) {
        bcc ^= data[i];
    }
    return bcc;
}

// 发送数据到上位机
void Comm_SendData(void) {
    uint8_t buffer[RECEIVE_DATA_SIZE] = {0};
    
    // 帧头
    buffer[0] = FRAME_HEADER;
    buffer[1] = tx_frame.flag;
    
    // 速度数据 (X, Y, Z)
    buffer[2] = (tx_frame.speed_x >> 8) & 0xFF;
    buffer[3] = tx_frame.speed_x & 0xFF;
    buffer[4] = (tx_frame.speed_y >> 8) & 0xFF;
    buffer[5] = tx_frame.speed_y & 0xFF;
    buffer[6] = (tx_frame.speed_z >> 8) & 0xFF;
    buffer[7] = tx_frame.speed_z & 0xFF;
    
    // 加速度数据 (X, Y, Z)
    buffer[8] = (tx_frame.acc_x >> 8) & 0xFF;
    buffer[9] = tx_frame.acc_x & 0xFF;
    buffer[10] = (tx_frame.acc_y >> 8) & 0xFF;
    buffer[11] = tx_frame.acc_y & 0xFF;
    buffer[12] = (tx_frame.acc_z >> 8) & 0xFF;
    buffer[13] = tx_frame.acc_z & 0xFF;
    
    // 陀螺仪数据 (X, Y, Z)
    buffer[14] = (tx_frame.gyro_x >> 8) & 0xFF;
    buffer[15] = tx_frame.gyro_x & 0xFF;
    buffer[16] = (tx_frame.gyro_y >> 8) & 0xFF;
    buffer[17] = tx_frame.gyro_y & 0xFF;
    buffer[18] = (tx_frame.gyro_z >> 8) & 0xFF;
    buffer[19] = tx_frame.gyro_z & 0xFF;
    
    // 电池电压
    buffer[20] = (tx_frame.voltage >> 8) & 0xFF;
    buffer[21] = tx_frame.voltage & 0xFF;
    
    // BCC校验和帧尾
    buffer[22] = Comm_CalculateBCC(buffer, 22);
    buffer[23] = FRAME_TAIL;
    
    // 发送（H7使用HAL_UART_Transmit）
    HAL_UART_Transmit(&huart3, buffer, RECEIVE_DATA_SIZE, 100);
}

// 处理接收到的字节
void Comm_ProcessByte(uint8_t data) {
    if(rx_index == 0) {
        if(data == FRAME_HEADER) {
            rx_buffer[rx_index++] = data;
        }
    } else {
        rx_buffer[rx_index++] = data;
        
        if(rx_index >= SEND_DATA_SIZE) {
            if(rx_buffer[SEND_DATA_SIZE - 1] == FRAME_TAIL) {
                uint8_t calc_bcc = Comm_CalculateBCC(rx_buffer, SEND_DATA_SIZE - 2);
                if(calc_bcc == rx_buffer[SEND_DATA_SIZE - 2]) {
                    // 解析数据
                    rx_frame.auto_recharge = rx_buffer[1];
                    rx_frame.security_level = rx_buffer[2];
                    rx_frame.speed_x = (int16_t)((rx_buffer[3] << 8) | rx_buffer[4]);
                    rx_frame.speed_y = (int16_t)((rx_buffer[5] << 8) | rx_buffer[6]);
                    rx_frame.speed_z = (int16_t)((rx_buffer[7] << 8) | rx_buffer[8]);
                    rx_flag = 1;  // 接收成功
                } else {
                    rx_flag = 2;  // 校验失败
                }
            } else {
                rx_flag = 2;  // 帧尾错误
            }
            rx_index = 0;
        }
    }
}

// 初始化通信
void Comm_Init(void) {
    // 启动串口中断接收
    uint8_t dummy;
    HAL_UART_Receive_IT(&huart3, &dummy, 1);
    
    // 初始化发送帧
    tx_frame.flag = 0x00;
}

// 串口接收中断回调
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    static uint8_t data;
    
    if(huart->Instance == USART3) {
        // 处理接收到的数据
        Comm_ProcessByte(data);
        
        // 继续接收下一个字节
        HAL_UART_Receive_IT(&huart3, &data, 1);
    }
}