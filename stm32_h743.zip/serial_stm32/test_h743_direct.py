#!/usr/bin/env python3
"""
直接测试 H743 串口通信
用法: python3 test_h743_direct.py [串口]
默认自动扫描所有可用串口
"""

import serial
import sys
import time
import glob

def find_serial_ports():
    ports = []
    for pattern in ['/dev/ttyUSB*', '/dev/ttyACM*']:
        ports.extend(glob.glob(pattern))
    return sorted(set(ports))

def test_port(port):
    """发送 A\n 并等待回复"""
    try:
        ser = serial.Serial(port, 115200, timeout=2.0)
    except Exception as e:
        print(f"  {port}: 无法打开 - {e}")
        return None

    ser.reset_input_buffer()
    ser.write(b'A\n')
    time.sleep(0.3)

    # 读取所有可用数据
    rx = b''
    while ser.in_waiting > 0:
        rx += ser.read(ser.in_waiting)
        time.sleep(0.1)

    ser.close()

    if rx:
        return {'port': port, 'data': rx}
    else:
        return {'port': port, 'data': b''}

def main():
    if len(sys.argv) > 1:
        ports = [sys.argv[1]]
    else:
        ports = find_serial_ports()

    if not ports:
        print("未找到串口！")
        sys.exit(1)

    print(f"扫描端口: {ports}")
    print("=" * 60)

    for port in ports:
        print(f"测试 {port}...", end=' ', flush=True)
        result = test_port(port)
        if result and result['data']:
            print(f"✅ 收到 {len(result['data'])} 字节")
            data = result['data']
            print(f"   HEX: {data.hex(' ')}")
            try:
                text = data.decode('ascii', errors='replace')
                print(f"   ASCII: {text}")
            except:
                pass
            if b'ARM_BUSY' in data:
                print(f"   👉 H743 在此端口！已回复 ARM_BUSY")
            elif b'ARM_DONE' in data:
                print(f"   👉 H743 在此端口！已回复 ARM_DONE")
        elif result:
            print("❌ 无回复")
        else:
            print("⚠ 打开失败")

    print("=" * 60)

if __name__ == '__main__':
    main()
