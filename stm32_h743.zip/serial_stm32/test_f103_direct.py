#!/usr/bin/env python3
"""
直接给 F103 发控制帧测试（自动扫描串口版）
用法: python3 test_f103_direct.py [串口] [speed] [steer]
不指定串口时自动扫描所有可用串口
"""

import serial
import sys
import time
import glob

FRAME_HEADER = 0xAA
FRAME_TAIL = 0x55
MSG_TYPE_CONTROL = 0x04

def build_frame(speed, steer, lateral=0, mode=1):
    data = bytearray(7)
    data[0] = speed & 0xFF
    data[1] = (speed >> 8) & 0xFF
    data[2] = steer & 0xFF
    data[3] = (steer >> 8) & 0xFF
    data[4] = lateral & 0xFF
    data[5] = (lateral >> 8) & 0xFF
    data[6] = mode
    checksum = 0
    for b in data:
        checksum ^= b
    frame = bytearray(12)
    frame[0] = FRAME_HEADER
    frame[1] = MSG_TYPE_CONTROL
    frame[2] = 7
    frame[3:10] = data
    frame[10] = checksum
    frame[11] = FRAME_TAIL
    return frame

def find_serial_ports():
    """扫描所有可用串口"""
    ports = []
    for pattern in ['/dev/ttyUSB*', '/dev/ttyACM*', '/dev/ttyS*']:
        ports.extend(glob.glob(pattern))
    return sorted(set(ports))

def test_port(port, speed, steer):
    """在指定端口发送测试帧并等待回复"""
    try:
        ser = serial.Serial(port, 115200, timeout=0.15)
    except Exception as e:
        print(f"  {port}: 无法打开 - {e}")
        return None

    ser.reset_input_buffer()
    frame = build_frame(speed, steer)
    ser.write(frame)
    time.sleep(0.2)

    rx = ser.read(ser.in_waiting or 1)
    ser.close()

    if rx:
        return {'port': port, 'bytes': len(rx), 'data': rx}
    else:
        return {'port': port, 'bytes': 0, 'data': b''}

def main():
    # 如果指定了串口，直接测试
    if len(sys.argv) > 1:
        ports = [sys.argv[1]]
    else:
        ports = find_serial_ports()
        if not ports:
            print("未找到任何串口！请检查 USB 连接。")
            print("可用的串口模式: /dev/ttyUSB* /dev/ttyACM* /dev/ttyS*")
            sys.exit(1)

    speed = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    steer = int(sys.argv[3]) if len(sys.argv) > 3 else 0

    print(f"扫描端口: {ports}")
    print(f"发送测试帧: speed={speed} steer={steer}")
    print("=" * 60)

    found_f103 = None

    if len(ports) == 1:
        # 单端口，直接测试
        port = ports[0]
        print(f"测试 {port}...")
        result = test_port(port, speed, steer)
        if result and result['bytes'] > 0:
            found_f103 = result
            print(f"  ✅ 收到 {result['bytes']} 字节: {result['data'].hex(' ')}")
        else:
            print(f"  ❌ 无回复 - 不是 F103 或连接有问题")
    else:
        # 多端口，逐个测试
        for port in ports:
            print(f"测试 {port}...", end=' ', flush=True)
            result = test_port(port, speed, steer)
            if result and result['bytes'] > 0:
                found_f103 = result
                print(f"✅ 收到 {result['bytes']} 字节: {result['data'].hex(' ')}")
            else:
                print(f"❌ 无回复")

    print("=" * 60)

    if found_f103:
        print(f"\n✅ F103 在 {found_f103['port']} 上!")
        data = found_f103['data']
        print(f"   回复 {found_f103['bytes']} 字节: {data.hex(' ')}")
        try:
            print(f"   ASCII: {data.decode('ascii', errors='replace')}")
        except:
            pass

        # ---- 连续测试 ----
        print(f"\n连续发送测试 (Ctrl+C 停止)...")
        ser = serial.Serial(found_f103['port'], 115200, timeout=0.05)
        frame = build_frame(speed, steer)
        count = 0
        try:
            while True:
                ser.write(frame)
                count += 1
                time.sleep(0.05)
                if count % 20 == 0:
                    n = ser.in_waiting
                    if n > 0:
                        data = ser.read(n)
                        print(f"\n  [{count}] RX {len(data)} bytes: {data.hex(' ')[:80]}...")
                    else:
                        print(f"\n  [{count}] RX 0 bytes", end='')
                    print('.', end='', flush=True)
        except KeyboardInterrupt:
            pass

        # 停车
        for _ in range(3):
            ser.write(build_frame(0, 0))
            time.sleep(0.05)
        ser.close()
        print(f"\n已停止。共发送 {count} 帧。")

    else:
        print("\n❌ 未找到 F103！所有端口都无回复。")
        print("\n可能原因:")
        print("  1. H743 的 USB-TTL 占了 /dev/ttyUSB0，F103 在 /dev/ttyUSB1")
        print("     → 尝试: python3 test_f103_direct.py /dev/ttyUSB1")
        print("  2. ST-Link VCP 注册为 /dev/ttyACM0 而不是 /dev/ttyUSB0")
        print("     → 尝试: python3 test_f103_direct.py /dev/ttyACM0")
        print("  3. F103 未上电或固件未运行（LED 是否闪烁？）")
        print("  4. 串口被其他程序占用（lsof /dev/ttyUSB*）")

if __name__ == '__main__':
    main()
